"use strict";
console.log("level 1 is ready!");
console.log("Child Origin is set to", window.origin);
var input_display_element = document.getElementById("level001Text");
window.addEventListener("message", function (event) {
    input_display_element.innerHTML = event.data;
    // if (event.origin == "index.html") {
    //   console.log("Same origin!");
    // } else {
    //   console.log("Different origin!");
    // }
});
